package hu.capsys.hb.transaction;

import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = TransactionServiceApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class AccountServiceApplicationTests {

    @Test
    void contextLoads() {
    }


    @LocalServerPort
    private int port;

    TestRestTemplate restTemplate = new TestRestTemplate();

    HttpHeaders headers = new HttpHeaders();

    @Test
    public void testRetrieveStudentCourse() throws JSONException {
String token = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiI5OTAwMjY3OTI1IiwiZXhwIjoxNjY5MjczNDE1LCJpYXQiOjE2NjkxODcwMTV9.X3IxUe1gKU_0JAZ0SRytaDYr6_UsA1yXTLgOYr9rqytV5aUL7d_16yq8e7tg9u2YK6oYW1mrZo-OAALn7ckCIA";
        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
                createURLWithPort("/api/accountnameornum?token="+token),
                HttpMethod.GET, entity, String.class);

        //String expected = "{\"id\":\"Course1\",\"name\":\"Spring\",\"description\":\"10 Steps\"}";
        String expected = "{\n" +
                "    \"id\": \"bcd7556a-a5b7-4b4a-89c6-15dac90a5d2f\",\n" +
                "    \"accountNo\": \"9900267925\",\n" +
                "    \"balance\": 1000,\n" +
                "    \"activityFlag\": 1,\n" +
                "    \"name\": \"abc\"\n" +
                "}";

        JSONAssert.assertEquals(expected, response.getBody(), false);
    }

    private String createURLWithPort(String uri) {
        return "http://localhost:" + port + uri;
    }

}
