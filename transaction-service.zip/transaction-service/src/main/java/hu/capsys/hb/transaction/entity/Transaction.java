package hu.capsys.hb.transaction.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;


import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Transaction  implements Serializable {


    private String id;
    @Id
    private String transferFrom;
    private String transferTo;
    private Long amount;
    private Date date;


    /*@Override
    public int compareTo(Transaction transaction) {
        return this.getDate().compareTo(transaction.getDate());
    }
*/

}
