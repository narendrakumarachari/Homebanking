package hu.capsys.hb.transaction.service;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class KafkaListen {
    private static final String TRANSACTION_TOPIC = "transaction";
    private final Logger logger = LogManager.getLogger(getClass());

    /*@KafkaListener(topics = TRANSACTION_TOPIC, groupId = "transaction")
    public void listenToTransaction(String transaction) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        Transaction response = objectMapper.readValue(transaction, Transaction.class);
        logger.info("Received Transaction from producer: {}", response.toString());
    }*/

}
