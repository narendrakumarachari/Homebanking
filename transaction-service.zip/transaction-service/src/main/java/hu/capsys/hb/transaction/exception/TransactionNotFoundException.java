package hu.capsys.hb.transaction.exception;

public class TransactionNotFoundException extends Throwable {
    public TransactionNotFoundException(String id) {
        super("Transaction id not found : " + id);
    }
}
