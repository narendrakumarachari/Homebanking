package hu.capsys.hb.party.service;

import hu.capsys.hb.party.entity.Account;
import hu.capsys.hb.party.entity.User;
import hu.capsys.hb.party.config.JwtTokenUtil;
import hu.capsys.hb.party.dao.AccountRepository;
import hu.capsys.hb.party.dto.Constants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    TransactionService transactionService;

    private final Logger logger = LogManager.getLogger(getClass());

    public String createAccount(User user) {
        Account account = new Account();
        account.setAccountNo(user.getContactNo());
        account.setBalance((long) 1000);
        accountRepository.save(account);
        return Constants.ACCOUNT_CREATED;
    }

    public Account getAccountFromToken(String token) {
        String contactNo = jwtTokenUtil.getUsernameFromToken(token);
        return accountRepository.findByAccountNo(contactNo);
    }

    public Account getAccountByAccountNo(String accountNo) {
        return accountRepository.findByAccountNo(accountNo);
    }

   //@Transactional(propagation = Propagation.REQUIRED)
    public void updateAccount(Account account) {
        accountRepository.save(account);
    }
}
