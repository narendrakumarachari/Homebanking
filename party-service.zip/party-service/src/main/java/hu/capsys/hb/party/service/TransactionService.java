package hu.capsys.hb.party.service;

import hu.capsys.hb.party.api.AccountControllerApiClient;

import hu.capsys.hb.party.config.TransactionControllerApiClient;
import hu.capsys.hb.party.entity.Account;
import hu.capsys.hb.party.entity.Transaction;
import hu.capsys.hb.party.exception.BadRequestException;
import hu.capsys.hb.party.config.JwtTokenUtil;
import hu.capsys.hb.party.dao.TransactionRepository;
import hu.capsys.hb.party.dto.Constants;
import hu.capsys.hb.party.dto.TransferMoneyDto;
import hu.capsys.hb.party.mapper.AccountDtoMapper;
import hu.capsys.hb.party.mapper.TransactionMapper;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private AccountService accountService;

    @Autowired
    KafkaTemplate<String, Transaction> kafkaTemplate;
    private static final String TOPIC = "transaction";

    @Autowired
    private AccountControllerApiClient accountControllerApiClient;

    @Autowired
    private TransactionControllerApiClient transactionControllerApiClient;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private AccountDtoMapper accountDtoMapper;

    @Autowired
    private TransactionMapper transactionMapper;

    private final Logger logger = LogManager.getLogger(getClass());

    public String transferMoney(TransferMoneyDto transferMoneyDto, String token) {
        String transferFrom = jwtTokenUtil.getUsernameFromToken(token);
        Account accountTo = accountService.getAccountByAccountNo(transferMoneyDto.getTransferTo());
        Account accountFrom = accountService.getAccountByAccountNo(transferFrom);
        if (accountFrom.getStatus() != 1 ) {
            logger.info("Account IS Temporarily SUSPENDED with account no : {}", accountFrom.getAccountNo());
            throw new BadRequestException("Account IS Temporarily SUSPENDED "+ accountFrom.getAccountNo());
        }
        if (accountTo.getStatus() != 1 ) {
            logger.info("Account IS Temporarily SUSPENDED with account no : {}", transferMoneyDto.getTransferTo());
            throw new BadRequestException("Account IS Temporarily SUSPENDED "+ accountTo.getAccountNo());
        }
        if (accountTo == null) {
            logger.info("Account not found with account no : {}", transferMoneyDto.getTransferTo());
            throw new BadRequestException("Account not found");
        }
        if (accountTo.getAccountNo().equals(accountFrom.getAccountNo())) {
            throw new BadRequestException("Can not transfer yourself");
        }
        if (accountFrom.getBalance() < transferMoneyDto.getAmount()) {
            logger.error("Not enough balance in account : {}", transferFrom);
            throw new BadRequestException("Not enough balance");
        }

        return makeTransaction(accountFrom, accountTo, transferMoneyDto.getAmount());


    }

    private String makeTransaction(Account accountFrom, Account accountTo, Long amount) {
        Transaction transaction = new Transaction();
        transaction.setAmount(amount);
        transaction.setTransferFrom(accountFrom.getAccountNo());
        transaction.setTransferTo(accountTo.getAccountNo());
        transaction.setDate(new Date());
        //Publish to KAFKA here
        kafkaTemplate.send(TOPIC, transaction);
        logger.info("Published Transaction to Kafka" + transaction.toString());
        transactionRepository.save(transaction);
        transactionControllerApiClient.saveTransaction(transactionMapper.tranactionToTranactionDto(transaction));
        accountFrom.setBalance(accountFrom.getBalance() - amount);
        accountControllerApiClient.updateAccBalance(accountDtoMapper.toDto(accountFrom));
        // accountService.updateAccount(accountFrom);
        accountTo.setBalance(accountTo.getBalance() + amount);
        accountControllerApiClient.updateAccBalance(accountDtoMapper.toDto(accountTo));
        //accountService.updateAccount(accountTo);
        return Constants.TRANSACTION_DONE;

    }

    public List<Transaction> getTransactionHostory(String token) {
        String accountNo = jwtTokenUtil.getUsernameFromToken(token);
        List<Transaction> transactions = new ArrayList<>();
        //transactions.addAll(transactionMapper.tranactionDtoToTranaction(transactionControllerApiClient.getTransactionHistory()));
        transactions.addAll(transactionRepository.findByTransferFrom(accountNo));
        transactions.addAll(transactionRepository.findByTransferTo(accountNo));
       // transactions.addAll(transactionControllerApiClient.getTransactionHistory());
        //transactions.sort(Collections.reverseOrder());
        return transactions;
    }
}
