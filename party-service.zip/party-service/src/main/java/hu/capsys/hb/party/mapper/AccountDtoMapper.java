package hu.capsys.hb.party.mapper;


import hu.capsys.hb.party.entity.Account;
import hu.capsys.hb.party.model.AccountDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface AccountDtoMapper {

/*    @Mapping(target = "id", source = "account.id")
    @Mapping(target = "accountNo", source = "account.accountNo")
    @Mapping(target = "balance", source = "account.balance")*/
    public AccountDto toDto(Account account);

}
