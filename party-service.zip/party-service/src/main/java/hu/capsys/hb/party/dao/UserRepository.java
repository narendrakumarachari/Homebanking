package hu.capsys.hb.party.dao;

import hu.capsys.hb.party.entity.User;
import org.elasticsearch.index.query.QueryBuilder;
import org.springframework.data.elasticsearch.annotations.Query;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface UserRepository extends ElasticsearchRepository<User, String> {

    User findByContactNo(String contactNo);

   /* @Query("{\"match\":{\"name\":\"?0\"}}")
    List<User> search(QueryBuilder query);*/

    List<User> findByName(String  name);

    //List<User> search(QueryBuilder query);
}
