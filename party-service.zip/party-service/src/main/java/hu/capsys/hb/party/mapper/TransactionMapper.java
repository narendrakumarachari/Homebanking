package hu.capsys.hb.party.mapper;



import hu.capsys.hb.party.entity.Transaction;
import hu.capsys.hb.party.model.TransactionDto;
import org.mapstruct.Mapper;

@Mapper(
        componentModel = "spring")
public interface TransactionMapper {

   // AccountDto accountToAccountDto(Account account);
    TransactionDto tranactionToTranactionDto(Transaction transaction);

 /*   @Named("date")
    default OffsetDateTime mapStartTime(TransactionDto dto, @Context DateTimeFormatter dateTimeFormatter) {

        LocalDateTime localDateTime = LocalDateTime.parse(dto.getDate().format(DateTimeFormatter.ISO_DATE_TIME), dateTimeFormatter);
        ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.of(dto. getDate().format(DateTimeFormatter.ISO_DATE_TIME)));
        return zonedDateTime.toOffsetDateTime();
    }*/


    Transaction tranactionDtoToTranaction(TransactionDto transactionDto);
}
