package hu.capsys.hb.party.controller;



import hu.capsys.hb.party.dto.Constants;
import hu.capsys.hb.party.dto.Response;
import hu.capsys.hb.party.entity.User;
import hu.capsys.hb.party.exception.BadRequestException;
import hu.capsys.hb.party.service.UserService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserService userService;

    private final Logger logger = LogManager.getLogger(getClass());

    @PostMapping("/user")
    public ResponseEntity<Response> createUser(@RequestBody User user) {
        try {
            return ResponseEntity.ok(new Response(Constants.SUCCESS, userService.createUser(user)));
        } catch (BadRequestException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response(Constants.ERROR, e.getMessage()));
        } catch (Exception e) {
            logger.error("error produced during creating user : {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/user")
    public ResponseEntity<User> getUserFromToken(HttpServletResponse response, HttpServletRequest request) {
        try {
            return ResponseEntity.ok(userService.getUserFromToken(request.getHeader("token")));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @GetMapping("/userbynameortype" )
    public ResponseEntity<List<User>> getUsersByNameOrType(HttpServletResponse response,
                                                     @RequestParam Optional<String> name,
                                                     @RequestParam Optional<String> type) {
        try {
            if(name.isPresent())
            return ResponseEntity.ok(userService.getUsersByNameOrType(name,type));
            else
               // return ResponseEntity.ok(null);
            return new ResponseEntity<List<User>>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @PutMapping("/user")
    public ResponseEntity<Response> updateUser(@RequestBody User user) {
        try {
            return ResponseEntity.ok(new Response(Constants.SUCCESS, userService.updateUser(user)));
        } catch (BadRequestException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response(Constants.ERROR, e.getMessage()));
        } catch (Exception e) {
            logger.info("error produced during updating user : {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response(Constants.ERROR, e.getMessage()));
        }
    }

}
