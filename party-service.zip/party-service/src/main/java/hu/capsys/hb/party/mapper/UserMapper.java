package hu.capsys.hb.party.mapper;


import hu.capsys.hb.party.entity.User;
import hu.capsys.hb.party.model.UserDto;
import org.mapstruct.Mapper;


@Mapper(
        componentModel = "spring"
)
public interface UserMapper {
    UserDto userToUserDTO(User user);
}
