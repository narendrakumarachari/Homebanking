package hu.capsys.hb.party.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;
import org.springframework.data.elasticsearch.annotations.Setting;


import javax.persistence.Id;
import java.time.ZonedDateTime;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Document(indexName = "partydataindex")
@Setting(settingPath = "es-config/elastic-analyzer.json")
public class User  {


   /* reference: text (length: 5-10)
    name: text (length: 1-50)
    type: possible values are OWNER/FAMILY/FRIEND/OTHER)*/
    @Id
    private String id;

    @Field(type = FieldType.Text, name = "reference")
    private String reference;

    @Field(type = FieldType.Text, name = "text")
    private String text;

    @Field(type = FieldType.Text, name = "type")
    private String type;

    @Field(type = FieldType.Text, name = "status")
    private String status;

    //@Field(type = FieldType.Text, name = "name")
    @Field(type = FieldType.Text, name = "name", analyzer = "autocomplete_index", searchAnalyzer = "autocomplete_search")
    private String name;

    @Field(type = FieldType.Text, name = "email")
    private String email;

    @Field(type = FieldType.Text, name = "contactNo")
    private String contactNo;

    @Field(type = FieldType.Text, name = "pin")
    private String pin;

    /*@Field(type = FieldType.Date, name = "dob", format = DateFormat.date_optional_time, pattern = "uuuu-MM-dd")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonSerialize(using = CustomLocalDateTimeSerializer.class)
    @JsonDeserialize(using = CustomLocalDateTimeDeserializer.class)
    private Date dob;*/

/* @Field(format = DateFormat.date_time, type = FieldType.Date)
 private Date dob;*/

    @Field(type = FieldType.Integer, name = "age")
    private int age;




}
