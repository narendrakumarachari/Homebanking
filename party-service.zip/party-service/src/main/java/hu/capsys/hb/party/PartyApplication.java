package hu.capsys.hb.party;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.elasticsearch.repository.config.EnableElasticsearchRepositories;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@OpenAPIDefinition(info = @Info(title = " Party Service",version = "1.0",
        description = "This Party serivice for Home Bank"))
@EnableFeignClients
/*@EnableElasticsearchRepositories(basePackages = "hu.capsys.hb.party.dao")
@EnableJpaRepositories(basePackages = {"hu.capsys.hb.party.dao"})*/
public class PartyApplication {

    public static void main(String[] args) {
        SpringApplication.run(PartyApplication.class, args);
    }

}
