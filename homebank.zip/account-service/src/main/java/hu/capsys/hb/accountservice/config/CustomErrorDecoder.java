/*
package hu.capsys.hb.accountservice.config;

import feign.Response;
import feign.codec.ErrorDecoder;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

public class CustomErrorDecoder implements ErrorDecoder {

    private final ErrorDecoder errorDecoder = new Default();

    @Override
    public Exception decode(String s, Response response) {
        String body = "4xx client error";
        try {
            body = new BufferedReader(response.body().asReader(StandardCharsets.UTF_8))
                    .lines()
                    .collect(Collectors.joining("\n"));
        } catch (IOException ignore) {}

        switch (response.status()) {

            case 404:
                return new FileNotFoundException(body);
            */
/*case 403:
                return new ForbiddenAccessException(body);*//*

        }

        return errorDecoder.decode(s, response);
    }
}
*/
