package hu.capsys.hb.accountservice.config;

import feign.RequestInterceptor;
        import feign.RequestTemplate;
        import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AccountInterceptor implements RequestInterceptor {
    @Override
    public void apply(RequestTemplate template) {
        log.info("Request Url: {}", template.url());
    }
}
