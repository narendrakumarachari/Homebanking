package hu.capsys.hb.accountservice.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hu.capsys.hb.accountservice.config.JwtTokenUtil;
import hu.capsys.hb.accountservice.constants.Constants;
import hu.capsys.hb.accountservice.dao.AccountRepository;
import hu.capsys.hb.accountservice.entity.Account;
import hu.capsys.hb.accountservice.mapper.AccountMapper;


import hu.capsys.hb.party.model.AccountDto;
import hu.capsys.hb.party.model.User;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    private final Logger logger = LogManager.getLogger(getClass());

    public AccountDto getAccountFromToken(String token) throws JsonProcessingException {
        String contactNo = jwtTokenUtil.getUsernameFromToken(token);
        Account account = accountRepository.findByAccountNo(contactNo);
        ObjectMapper mapper = new ObjectMapper();
        mapper.writeValueAsString(account);
        logger.info(mapper.writeValueAsString(account));
        AccountDto accountDto = accountMapper.accountToAccountDto(account);
        return accountDto;
    }

    public String createUserAccount(User user) {
        Account account = new Account();
        account.setAccountNo(user.getContactNo());
        account.setBalance((long) 1000);
        account.setName(user.getName());
        account.setDescription(user.getEmail() + user.getText());
        accountRepository.save(account);
        return Constants.ACCOUNT_CREATED;
        //return null;
    }

    public List<AccountDto> getByNamOrNum(String name, String num) {
        List<AccountDto> accountDtoList = new ArrayList<>();
        List<Account> accountList = null;
        AccountDto accountDto = null;
        if (name != null && num != null) {
            accountList = accountRepository.findByNameAndNum(name, num);
        } else if (name == null) {
            accountList = accountRepository.findByNum(num);
        } else if (num == null) {
            accountList = accountRepository.findByName(name);
        }
        if (accountList != null) {
            accountList.stream().forEach(x -> {
                accountDtoList.add(accountMapper.accountToAccountDto(x));
            });

        }
        //accountDtoList.add(accountDto);
        return accountDtoList;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED)
    public AccountDto updateAccBalance(AccountDto accountDto) {
        Account account1 = accountRepository.findByAccountNo(accountDto.getAccountNo());
        account1.setBalance(accountDto.getBalance());
        Account account = accountRepository.save(account1);
        return accountMapper.accountToAccountDto(account);
    }

    public AccountDto updateAccountStatus(String accountNo) {
        Account account1 = accountRepository.findByAccountNo(accountNo);
        if (account1.getStatus() == 0) {
            account1.setStatus(1);
        } else {
            account1.setStatus(0);
        }
        Account account = accountRepository.save(account1);
        return accountMapper.accountToAccountDto(account);
    }
}
