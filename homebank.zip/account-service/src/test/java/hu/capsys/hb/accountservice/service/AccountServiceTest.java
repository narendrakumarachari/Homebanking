package hu.capsys.hb.accountservice.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hu.capsys.hb.accountservice.config.JwtTokenUtil;
import hu.capsys.hb.accountservice.dao.AccountRepository;
import hu.capsys.hb.accountservice.entity.Account;
import hu.capsys.hb.accountservice.mapper.AccountMapper;
import hu.capsys.hb.party.model.AccountDto;
import hu.capsys.hb.party.model.User;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
class AccountServiceTest {

    @InjectMocks
    AccountService accountService;

    @Mock
    private JwtTokenUtil jwtTokenUtil;

    @Mock
    private AccountRepository accountRepository;
    @Mock
    private AccountMapper accountMapper;


    Account account;

    @BeforeEach
    void setUp() {
        Account account = new Account();
        account.setAccountNo("9900264334");
        account.setBalance((long) 1000);
        account.setName(            "capsys"        );
        account.setDescription("Desc");
        account.setStatus(1);
        AccountDto accountDto = new AccountDto();
        accountDto.setAccountNo("9900264334");
        accountDto.setBalance((long) 1000);
        accountDto.setName(            "capsys"        );
        accountDto.setDescription("Desc");


    }

    @Test
    void createUserAccount() {

        User user = new User();
        user.setContactNo("9900267925");
        user.setName("Capsys");
        Account account = new Account();
        account.setAccountNo(user.getContactNo());
        account.setBalance((long) 1000);
        account.setName(user.getName());
        account.setDescription(user.getEmail() + user.getText());
        when(accountRepository.save(account)).thenReturn(account);
        assertEquals("Account created", accountService.createUserAccount(user));

    }

    @Test
    void testInVTokenAccount() throws JsonProcessingException {
        String  token = "Invalid";
        when(jwtTokenUtil.getUsernameFromToken(token)).thenReturn(null);
        when(accountRepository.findByAccountNo(null)).thenReturn(null);
        assertEquals(null , accountService.getAccountFromToken(token));
    }










    @Test
    void testNameNumAccount(){
        List<AccountDto> capsys = accountService.getByNamOrNum("capsys", "9900");
        assertEquals(0, capsys.size());
    }

    @Test
    void testNameAccount(){
        List<AccountDto> capsys = accountService.getByNamOrNum("capsys",null);
        assertEquals(0, capsys.size());
    }

    @Test
    void testNumAccount(){
        List<AccountDto> capsys = accountService.getByNamOrNum(null,"9900");
        assertEquals(0, capsys.size());
    }

    private List<Account> createAccountList() {
        List<Account> accountList = new ArrayList<>();
        User user = new User();
        user.setContactNo("9900267925");
        user.setName("Capsys");
        Account account = new Account();
        account.setAccountNo(user.getContactNo());
        account.setBalance((long) 1000);
        account.setName(user.getName());
        account.setDescription(user.getEmail() + user.getText());
        account.setStatus(1);
        accountList.add(account);
        return accountList;

    }
    private Account createAccount(){

        Account account = new Account();
        account.setAccountNo("9900264334");
        account.setBalance((long) 1000);
        account.setName(            "capsys"        );
        account.setDescription("Desc");
        account.setStatus(1);
        return account;
    }

    private List<AccountDto> createAccountDtoList() {
        List<AccountDto> accountList = new ArrayList<>();
        User user = new User();
        user.setContactNo("9900267925");
        user.setName("Capsys");
        AccountDto account = new AccountDto();
        account.setAccountNo(user.getContactNo());
        account.setBalance((long) 1000);
        account.setName(user.getName());
        account.setDescription(user.getEmail() + user.getText());
        accountList.add(account);
        return accountList;

    }

}
