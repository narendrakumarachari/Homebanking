package hu.capsys.hb.transaction.mapper;



import hu.capsys.hb.transaction.entity.Transaction;


import hu.capsys.hb.transaction.model.TransactionDto;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Named;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

@Mapper(
        componentModel = "spring")
public interface TransactionMapper {

   // AccountDto accountToAccountDto(Account account);
    TransactionDto tranactionToTranactionDto(Transaction transaction);

 /*   @Named("date")
    default OffsetDateTime mapStartTime(TransactionDto dto, @Context DateTimeFormatter dateTimeFormatter) {

        LocalDateTime localDateTime = LocalDateTime.parse(dto.getDate().format(DateTimeFormatter.ISO_DATE_TIME), dateTimeFormatter);
        ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.of(dto. getDate().format(DateTimeFormatter.ISO_DATE_TIME)));
        return zonedDateTime.toOffsetDateTime();
    }*/


    Transaction tranactionDtoToTranaction(TransactionDto transactionDto);
}
