package hu.capsys.hb.transaction.dao;

import hu.capsys.hb.transaction.entity.Transaction;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RedisTransactionRepo {


    public static final String TRANSACTION = "TRANSACTION";
    private HashOperations hashOperations;

    private RedisTemplate redisTemplate;

    public RedisTransactionRepo(RedisTemplate redisTemplate){
        this.redisTemplate = redisTemplate;
        this.hashOperations = this.redisTemplate.opsForHash();
    }

    public void save(Transaction transaction){
        hashOperations.put(TRANSACTION, transaction.getTransferFrom()+transaction.getDate(), transaction);
    }
    public List<Transaction> findAll(){
        return hashOperations.values(TRANSACTION);
    }

    public Transaction findById(String id){
        return (Transaction) hashOperations.get(TRANSACTION, id);
    }

    public void update(Transaction transaction){
        save(transaction);
    }

    public void delete(String id){
        hashOperations.delete(TRANSACTION, id);
    }

    public Transaction findByTransferFrom(String transferFrom){

        return (Transaction) hashOperations.get(TRANSACTION, transferFrom);
    }

    public Transaction findByTransferTo(String transferTo){

        return (Transaction) hashOperations.get(TRANSACTION, transferTo);
    }
}
