package hu.capsys.hb.transaction.controller;

import hu.capsys.hb.transaction.api.TransactionControllerApi;
import hu.capsys.hb.transaction.constants.Constants;
import hu.capsys.hb.transaction.entity.Transaction;
import hu.capsys.hb.transaction.exception.BadRequestException;
import hu.capsys.hb.transaction.mapper.TransactionMapper;
import hu.capsys.hb.transaction.model.Response;
import hu.capsys.hb.transaction.model.TransactionDto;
import hu.capsys.hb.transaction.service.TransactionService;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/api")
public class TransactionController implements TransactionControllerApi {


    private final Logger logger = LogManager.getLogger(getClass());
    @Autowired
    private TransactionService transactionService;
    @Autowired
    private TransactionMapper transactionMapper;

    @Override
    public ResponseEntity<List<TransactionDto>> getTransactionHistory() {
        //return (ResponseEntity<List<TransactionDto>>) transactionService.getAllTransactions();
        // return  ResponseEntity.ok(transactionService.getAllTransactions());



        try {
            return ResponseEntity.ok(
                    transactionService.getAllTransactions());
        } catch (BadRequestException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @Override
    public ResponseEntity<Response> saveTransaction(TransactionDto transactionDto) {
        try {
            ///ResponseEntity.ok(new Response(Constants.SUCCESS, transactionService.transferMoney(transferMoneyDto, request.getHeader("token"))));
            return ResponseEntity.ok(new Response(Constants.SUCCESS, transactionService.addTransaction(transactionDto).toString()));
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("error getting transaction history : {}", e.getMessage());
            // return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
        }
        return null;


    }









/*    @Override
    public ResponseEntity<List<TransactionDto>> getTransactionHistory() {
        try {
            return (ResponseEntity<List<TransactionDto>>) transactionService.getAllTransactions();
        } catch (Exception e) {
            logger.error("error produced getting transaction history : {}", e.getMessage());
           // return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
        }

        return null;
    }

    @Override
    public ResponseEntity<List<TransactionDto>> saveTransaction(Transaction transaction) {

        try {
            return (ResponseEntity<List<TransactionDto>>) transactionService.addTransaction(transaction);
        } catch (Exception e) {
            logger.error("error produced getting transaction history : {}", e.getMessage());
            // return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
        }
        return null;
    }*/


}
