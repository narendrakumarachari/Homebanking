package hu.capsys.hb.transaction.service;

import hu.capsys.hb.transaction.dao.RedisTransactionRepo;
import hu.capsys.hb.transaction.entity.Transaction;
import hu.capsys.hb.transaction.mapper.TransactionMapper;

import hu.capsys.hb.transaction.model.TransactionDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

@Service
public class TransactionService {




    @Autowired
    private RedisTransactionRepo redisTransactionRepo;

    @Autowired
    private TransactionMapper transactionMapper;

    //private  TransactionM


    public List<TransactionDto> getAllTransactions() {
        List<Transaction> transactionList = redisTransactionRepo.findAll();
        List<TransactionDto> transactionDtoList = new ArrayList<>();
        transactionList.stream().forEach(x->{
            TransactionDto transactionDto = transactionMapper.tranactionToTranactionDto(x);
            transactionDtoList.add(transactionDto);

        });
        return transactionDtoList;
    }

   /* public Transaction addTransaction(T transaction){
        transaction.setId(generateUUID());
        redisTransactionRepo.save(transaction);
        return redisTransactionRepo.findById(transaction.getId());
    }
*/


    public TransactionDto addTransaction(TransactionDto transactionDto) {
        transactionDto.setTransferFrom(transactionDto.getTransferFrom());
        transactionDto.setId(UUID.randomUUID().toString().substring(0,8));
        redisTransactionRepo.save(transactionMapper.tranactionDtoToTranaction(transactionDto));
       // Transaction transactionRepoById = redisTransactionRepo.findById(transactionDto.getId().toString());
        Transaction transactionRepoById = new Transaction();
        return transactionMapper.tranactionToTranactionDto(transactionRepoById);
    }
}
