package hu.capsys.hb.party.dto;

import java.util.Random;

public enum PartyTypeEnum {
    OWNER, FAMILY, FRIEND, OTHER;
    private static final Random PRNG = new Random();


    public static String randomPartyType()  {
        PartyTypeEnum[] partyTypeEnums = values();
        return partyTypeEnums[PRNG.nextInt(partyTypeEnums.length)].toString();
    }
}
