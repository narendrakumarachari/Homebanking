package hu.capsys.hb.party.config;

import org.openapitools.configuration.ClientConfiguration;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name="${transactionController.name:transactionController}", url="${transactionController.url:http://localhost:8085}", configuration = ClientConfiguration.class)
public interface TransactionControllerApiClient extends TransactionControllerApi {
}
