package hu.capsys.hb.party.service;

import feign.RetryableException;
import hu.capsys.hb.party.api.AccountControllerApiClient;
import hu.capsys.hb.party.entity.User;
import hu.capsys.hb.party.exception.BadRequestException;
import hu.capsys.hb.party.config.JwtTokenUtil;
import hu.capsys.hb.party.dao.UserRepository;
import hu.capsys.hb.party.dto.Constants;
import hu.capsys.hb.party.dto.PartyTypeEnum;
import hu.capsys.hb.party.mapper.UserMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.elasticsearch.index.query.QueryBuilders;
import org.joda.time.DateTime;
import org.joda.time.Years;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.query.NativeSearchQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AccountService accountService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private ElasticsearchRestTemplate elasticsearchRestTemplate;

    @Autowired
    private AccountControllerApiClient accountFeign;

    @Autowired
    private UserMapper userMapper;

    private final Logger logger = LogManager.getLogger(getClass());


    private final RestTemplate restTemplate;

    public UserService() {
        this.restTemplate = new RestTemplate();
    }

    public String createUser(User user) {
        if (userRepository.findByContactNo(user.getContactNo()) != null) {
            logger.info("user already exist with mobile number : {}", user.getContactNo());
            throw new BadRequestException(Constants.USER_EXIST);
        }
        UUID uuid = UUID.randomUUID();
        user.setReference(uuid.toString());
        user.setType(PartyTypeEnum.randomPartyType());
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        user.setPin(encoder.encode(user.getPin()));
        Date now = new Date();
        // user.setAge(getAgeBetween(user.getDob(), now));
        ResponseEntity<String> account = createUserAndAccount(user);
        //return accountService.createAccount(user);
        return account.toString();
    }

    //@Transactional(rollbackFor = RetryableException.class)
    ResponseEntity<String> createUserAndAccount(User user) {
        user = userRepository.save(user);
        ResponseEntity<String> account = accountFeign.createAccount(userMapper.userToUserDTO(user));
        return account;
    }

    /*    */
    private List<User> getElasticData(Optional<String> userName, Optional<String> type) {

        NativeSearchQuery query = new NativeSearchQueryBuilder().build();
        if (type.isPresent() && !userName.isPresent()) {
            logger.info("-------------------Search By type--------->>>>>>>>>" + type);
            query = new NativeSearchQueryBuilder().
                    withQuery(QueryBuilders.matchQuery("type", type.get()))
                    .build();
        } else if (userName.isPresent() && !type.isPresent()) {
            logger.info("-------------------Search By Name--------->>>>>>>>>" + userName);
            query = new NativeSearchQueryBuilder()
                    .withQuery(QueryBuilders.matchQuery("name", userName.get()))
                    .build();
        } else if (userName.isPresent() && type.isPresent()) {
            logger.info("-------------------Search By Name & Type--------->>>>>>>>>" + userName + type);
            query = new NativeSearchQueryBuilder()
                    .withQuery(QueryBuilders.matchQuery("name", userName.get()))
                    .withQuery(QueryBuilders.matchQuery("type", type.get()))
                    .build();
        }
        SearchHits<User> searchHits = elasticsearchRestTemplate.search(query, User.class);
        return searchHits.get().map(SearchHit::getContent).collect(Collectors.toList());
    }


/*
    public List<User> autoSuggestionSearch (String keywords) {
        MatchQueryBuilder searchByName = QueryBuilders.matchQuery("name", keywords);
       // return userRepository.search(searchByName.);
        return userRepository.search(searchByName);
    }
*/

    private int getAgeBetween(Date dob, Date now) {
        DateTime dobjoda = new DateTime(dob);
        DateTime nowjoda = new DateTime(now);
        return Years.yearsBetween(dobjoda, nowjoda).getYears();
    }


    public User getUserFromToken(String token) {
        String contactNo = jwtTokenUtil.getUsernameFromToken(token);

        logger.info(accountFeign.getAccountDetails(token));
        // logger.info(accountDetails.get(0).toString());
        return userRepository.findByContactNo(contactNo);
    }

    public String updateUser(User user) {
        User existingUser = userRepository.findByContactNo(user.getContactNo());
        if (existingUser == null) {
            logger.info("User not found with contact no : {}", user.getContactNo());
            throw new BadRequestException("User not found with contact no : " + user.getContactNo());
        }
        user.setId(existingUser.getId());
        user.setContactNo(existingUser.getContactNo());
        user.setPin(existingUser.getPin());
        //user.setAge(getAgeBetween(user.getDob(),new Date()));
        userRepository.save(user);
        return Constants.USER_UPDATED;
    }

    public List<User> getUsersByNameOrType(Optional<String> name, Optional<String> type) {
        List<User> userList = getElasticData(name, type);
        userList.stream().forEach(x -> {
            logger.info(x.getId());
            logger.info(x);
        });
        return userList;
    }


}
