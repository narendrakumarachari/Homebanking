package hu.capsys.hb.accountservice.controller;

import hu.capsys.hb.accountservice.service.AccountService;
import hu.capsys.hb.party.api.AccountControllerApi;
import hu.capsys.hb.party.model.AccountDto;

import hu.capsys.hb.party.model.User;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
public class AccountController implements AccountControllerApi {
    @Autowired
    private AccountService accountService;

    private final Logger logger = LogManager.getLogger(getClass());

    @Override
    public ResponseEntity<String> createAccount(User user) {
        try {
            return ResponseEntity.ok(accountService.createUserAccount(user));
        } catch (Exception e) {
            logger.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @Override
    public ResponseEntity<List<AccountDto>> getAccountByNameOrNum(String name, String num) {
        try {
            return  ResponseEntity.ok(accountService.getByNamOrNum(name,num));
        } catch (Exception e) {
            logger.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }





    @Override
    public ResponseEntity<AccountDto> getAccountDetails(String token) {
        try {
            return ResponseEntity.ok(accountService.getAccountFromToken(token));
        } catch (Exception e) {
            logger.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @Override
    public ResponseEntity<AccountDto> updateAccBalance(AccountDto account) {
        try {
            return ResponseEntity.ok(accountService.updateAccBalance(account));
        } catch (Exception e) {
            logger.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @Override
    public ResponseEntity<AccountDto> updateAccountStatus(String accountNo) {
        try {
            return ResponseEntity.ok(accountService.updateAccountStatus(accountNo));
        } catch (Exception e) {
            logger.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
