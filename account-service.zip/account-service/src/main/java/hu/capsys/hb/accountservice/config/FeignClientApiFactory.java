package hu.capsys.hb.accountservice.config;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class FeignClientApiFactory {

   /* private final Feign.Builder feignBuilder;

    public <T> T getClient(Class<T> clientType, String url) {
        return feignBuilder
                .retryer(Retryer.NEVER_RETRY)
                .target(clientType, url);
    }

    public <T> T getClient(Class<T> clientType, String url, Decoder decoder) {
        return feignBuilder
                .decoder(decoder)
                .retryer(Retryer.NEVER_RETRY)
//                .requestInterceptor(feignRequestInterceptor)
                .target(clientType, url);
    }*/

}
