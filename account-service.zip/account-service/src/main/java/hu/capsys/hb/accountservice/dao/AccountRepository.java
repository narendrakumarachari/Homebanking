package hu.capsys.hb.accountservice.dao;


import hu.capsys.hb.accountservice.entity.Account;
import org.hibernate.annotations.OptimisticLock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.persistence.LockModeType;
import java.util.List;

@Repository
public interface AccountRepository extends JpaRepository<Account,String> {

    Account findByAccountNo(String contactNo);
    //@Query(value = " select * from account where name=\"abc\";",countQuery = "",nativeQuery = true)
    @Query(value = "select * from account  where name like %:name% or account_no like %:num%",
            countQuery = "",
            nativeQuery = true)
    List<Account> findByNameAndNum(@Param("name") String name, @Param("num") String num);

//select iu from account iu where iu.name like %nar% or iu.account_no like %9900% %:text%
    @Query(value = "select * from account  where account_no like %:num%",countQuery = "",nativeQuery = true)
    List<Account> findByNum(@Param("num") String num);

    @Query(value = " select * from account  where name like %:name%",countQuery = "",nativeQuery = true)
    List<Account> findByName(@Param("name") String name);



  /*  @Lock(LockModeType.OPTIMISTIC_FORCE_INCREMENT)
    @Query(value =  "SELECT a FROM Account a WHERE c.accountNo = ?1")
    public Account findByAccountNo(String orgId);*/
}
