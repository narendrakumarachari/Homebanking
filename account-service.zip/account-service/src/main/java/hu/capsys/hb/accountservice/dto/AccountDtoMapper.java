package hu.capsys.hb.accountservice.dto;

import hu.capsys.hb.accountservice.entity.Account;
import hu.capsys.hb.party.model.AccountDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface AccountDtoMapper {

/*    @Mapping(target = "id", source = "account.id")
    @Mapping(target = "accountNo", source = "account.accountNo")
    @Mapping(target = "balance", source = "account.balance")*/
    public AccountDto toDto(Account account);

}
