package hu.capsys.hb.accountservice.mapper;

import hu.capsys.hb.accountservice.dto.UserDto;

import hu.capsys.hb.accountservice.entity.Account;
import hu.capsys.hb.party.model.AccountDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(
        componentModel = "spring"

)
public interface AccountMapper
{


    AccountDto accountToAccountDto(Account account);
    Account accountDtotoAccount(AccountDto accountDto);
}
