package hu.capsys.hb.accountservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UserDto {
    private String id;

    private String reference;

    private String text;

    private String type;

    private String status;

    private String name;

    private String email;

    private String contactNo;

    private String pin;

    private int age;
}
