package hu.capsys.hb.accountservice;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


/*@AutoConfigureStubRunner(
        stubsMode = StubRunnerProperties.StubsMode.LOCAL,
        ids = {
                "hu.capsys:cs_party-server:1.9.0-SNAPSHOT:stubs:8180",
                "hu.capsys:crypto-server:1.9.0-SNAPSHOT:stubs:8093"
        })
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@IntegrationTest*/

@SpringBootTest
@AutoConfigureMockMvc
//@TestPropertySource(properties = "spring.main.allow-bean-definition-overriding=true")
public class AccountControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void shouldAbleToUpdateAccount() throws Exception {
        mockMvc.perform(put("/api/updateaccount")
                        .contentType(APPLICATION_JSON)
                        .content("{\n" +
                                "   \n" +
                                "    \"accountNo\": \"9900000049\",\n" +
                                "    \"balance\": 997,\n" +
                                "    \"activityFlag\": 1,    \n" +
                                "    \"description\": \"desc\",\n" +
                                "    \"status\":0\n" +
                                "}"
                        )
                )
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content()
                        .json("{\n" +
                                "    \"accountNo\": \"9900000049\",\n" +
                                "    \"balance\": 997,\n" +
                                "    \"activityFlag\": 1,\n" +
                                "    \"name\": \"Naenrdfs\",\n" +
                                "    \"description\": \"abcd@capsys.hunull\"\n" +
                                "}"
                        )
                )
                .andExpect(content().contentTypeCompatibleWith(APPLICATION_JSON));
    }


}
